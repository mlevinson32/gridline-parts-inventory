# Gridline Parts Inventory — MyGeotab Add-In

A parts inventory tracker built as a MyGeotab Add-In: look up a SKU, see quantity on hand, and get flagged when a part hits its reorder point. Data is shared across your whole team, stored in your MyGeotab database via Geotab's own `AddInData` storage API — not stuck on one browser.

## What's in this package

- `index.html` — the full add-in (HTML/CSS/JS). This needs to be hosted at a real URL.
- `config.json` — the manifest MyGeotab reads. It points at wherever you host `index.html`.
- `README.md` — this file.

## Why hosting, not copy-paste

We tried embedding the whole app directly inside `config.json` so nothing needed hosting. That's a real, documented Geotab feature, but in practice it ran into a caching problem on this MyGeotab instance: your browser console showed embedded add-ins being served from a static-CDN domain (`myg-static.geotab.com`) at a path keyed off the add-in's name, and updates weren't reliably showing up even after deleting the add-in and logging out. Hosting `index.html` at a real URL sidesteps that entirely — it's also the pattern every one of Geotab's own official sample add-ins actually uses, so it's the proven path.

## Step 1 — Host index.html on GitHub Pages (free, ~5 minutes)

1. Go to [github.com](https://github.com) and sign in (or create a free account).
2. Click the **+** in the top right → **New repository**. Name it `gridline-parts-inventory`. Set it to **Public**. Create it.
3. On the repo page, click **Add file → Upload files**, upload this package's `index.html`, and commit.
4. Go to **Settings → Pages** (left sidebar of the repo).
5. Under "Build and deployment," set **Source** to **Deploy from a branch**, branch **main**, folder **/ (root)**. Save.
6. Wait about a minute, refresh that Settings → Pages screen — GitHub shows a live URL, e.g.:
   `https://yourusername.github.io/gridline-parts-inventory/index.html`
7. Open that URL directly in a browser tab. You should see the Parts Inventory page load (it'll just spin on "Loading inventory…" since it's not inside MyGeotab yet — that's expected and fine).

## Step 2 — Point config.json at that URL

Open `config.json` and replace `https://YOUR-GITHUB-USERNAME.github.io/gridline-parts-inventory/index.html` (in the `"url"` field) with your real URL from Step 1.

## Step 3 — Install into MyGeotab

1. Sign in to MyGeotab as an Administrator.
2. Go to **Administration → System Settings → Add-Ins** tab.
3. Delete any earlier version of this add-in if it's still listed.
4. Click **New Add-In**, and paste in (or upload) your edited `config.json`.
5. Click **OK**, then confirm/enable the add-in.
6. A **Parts Inventory** menu item appears in the left-hand Activity menu, with the Gridline logomark as its icon.

## Updating it later

Edit `index.html`, re-upload it to the same GitHub repo (commit the change), and it's live at the same URL — no need to touch `config.json` or MyGeotab again. If a change doesn't seem to show up, do a hard refresh (Ctrl+Shift+R / Cmd+Shift+R); if it's still stale, add a cache-busting query string to the URL in `config.json` (e.g. `...index.html?v=2`) and bump it.

## How it works

- **SKU lookup**: search bar filters by SKU, description, or supplier as you type.
- **Quantity tracking**: each part has a Qty on Hand, a Reorder At threshold, and a Reorder Qty. The +/- steppers adjust stock in place.
- **Low-stock detection**: any part at or below its Reorder At threshold shows a "Reorder" (or "Out of stock") badge and rolls into the banner at the top.
- **Data storage**: every part and the reminder settings are stored as `AddInData` records in your MyGeotab database, scoped to this add-in — shared across everyone who opens it.
- **CSV import/export**: bulk-load an existing parts list, or pull the current inventory out to a spreadsheet.

## Reminders — the limitation worth knowing

MyGeotab Add-Ins run as client-side JavaScript in the browser — there's no built-in way for one to send email or SMS on its own. This build handles that in two tiers:

1. **In-app** (works immediately): opening the add-in checks for low stock and shows the banner.
2. **Email/SMS via webhook** (one-time, no-code setup): in Reminder Settings, paste a webhook URL from Zapier, Make, or Power Automate. When stock is low, the add-in POSTs a JSON payload of the affected parts; you add a "Send Email" step on the other end. Fires once per SKU per day automatically, plus there's a manual "Send Reminder Now" button.

For reminders that fire even when nobody has the add-in open, point an external scheduled job at the MyGeotab API (`Authenticate`, then `Get` on `AddInData`) and reuse the same webhook pattern — that's a small backend task outside what a client-side add-in can do alone.

## Going to production

- **AddInData isolation**: this build uses a fixed `ADDIN_ID` constant near the top of `index.html`'s `<script>` block. Each customer's data lives in their own MyGeotab database regardless, so there's no cross-customer leakage — but regenerate that ID for a fresh install if you want extra separation.
- **Multi-location scoping**: `AddInData` supports scoping to MyGeotab Groups, which would let you restrict a depot's parts list to that depot's users. Not wired up here — flag it if a customer needs it.
- **Security review**: this add-in requests no special MyGeotab clearances beyond standard Add-In access, and only calls out to the webhook URL a fleet admin configures themselves. Worth a review before wide distribution.
